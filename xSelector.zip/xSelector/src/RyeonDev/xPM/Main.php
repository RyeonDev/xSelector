<?php

namespace RyeonDev\xPM;

use pocketmine\Server;

use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;

use jojoe77777\FormAPI\SimpleForm;

class Main extends PluginBase {

    public function onEnable(): void {
        $this->getLogger()->info("xSelector has been active");
    }

    public function onDisable(): void {
        $this->getLogger()->info("xSelector has been unactive");
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "selector") {
            if ($sender instanceof Player) {
                $this->openSelectorForm($sender);
            } else {
                $sender->sendMessage("This command can only be used in-game.");
            }
            return true;
        }
        return false;
    }

    public function openSelectorForm(Player $player) {
        $form = new SimpleForm(function (Player $player, ?int $data) {
            if ($data !== null) {
                switch ($data) {
                    case 0:
                        $player->sendMessage(" ganti pake command"); //dengan $this->getServer()->dispatchCommand($player, "command mu");
                        break;
                    case 1:
                        $this->getServer()->dispatchCommand($player, "transferserver Skyblock");
                        break;
                    case 2:
                        $this->openSurvivalForm($player);
                        break;
                    case 3:
                        $this->openLobbyForm($player);
                        break;
                    case 4:
                        
                        break;
                }
            }
        });

        $form->setTitle("SERVER SELECTOR");
        $form->addButton("ACID ISLAND\nClick here");
        $form->addButton("SKYBLOCK\nClick here");
        $form->addButton("SURVIVAL\nClick here");
        $form->addButton("LOBBY\nClick here");
        $form->addButton("§cEXIT§r", 0, "textures/blocks/barrier");

        $player->sendForm($form);
    }
    
    public function openSurvivalForm(Player $player) {
        $form = new SimpleForm(function (Player $player, ?int $data) {
            if ($data !== null) {
                switch ($data) {
                    case 0:
                        $this->getServer()->dispatchCommand($player, "transferserver Survival");
                        break;
                    case 1:
                        $player->sendMessage("§cSurvival Vanilla Belum Tersedia Sekarang");
                        break;
                    case 2:
                        $this->openSelectorForm($player);
                        break;
                        
                }
            }
        });

        $form->setTitle("SURVIVAL");
        $form->addButton("ECONOMY\nClick here");
        $form->addButton("VANILLA\nClick here");
        $form->addButton("BACK\nClick here");

        $player->sendForm($form);
    }
    
    public function openLobbyForm(Player $player) {
        $form = new SimpleForm(function (Player $player, ?int $data) {
            if ($data !== null) {
                switch ($data) {
                    case 0:
                        $player->sendMessage("Ganti jadi command run"); //dengan $this->getServer()->dispatchCommand($player, "command mu");
                        break;
                    case 1:
                        $player->sendMessage("Ganti juga"); //dengan $this->getServer()->dispatchCommand($player, "command mu");
                        break;
                    case 2:
                        $this->openSelectorForm($player);
                        break;
                }
            }
        });

        $form->setTitle("LOBBY");
        $form->addButton("LOBBY §a#1§r\nClick here");
        $form->addButton("LOBBY §a#2§r\nClick here");
        $form->addButton("BACK\nClick here");
        
        $player->sendForm($form);
    }
}
